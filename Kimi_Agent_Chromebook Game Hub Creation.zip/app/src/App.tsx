import { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  ExternalLink, 
  Shield, 
  Eye, 
  EyeOff, 
  Play, 
  Search,
  X,
  Monitor,
  BookOpen,
  FileText,
  Home,
  Sparkles,
  Zap,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import './App.css';

// Game type definition
interface Game {
  id: string;
  name: string;
  category: string;
  thumbnail: string;
  url: string;
  description: string;
}

// Cloak type
type CloakType = 'none' | 'blank' | 'classroom' | 'newtab';

// Games data - 100+ Popular Chromebook-compatible games
const games: Game[] = [
  { id: '1', name: 'Slope', category: 'Arcade', thumbnail: '', url: 'https://slope-game.github.io/rungame/slope/', description: 'Roll down the slope and avoid obstacles' },
  { id: '2', name: 'Subway Surfers', category: 'Endless Runner', thumbnail: '', url: 'https://subway-surfers.org/', description: 'Run through the subway and dodge trains' },
  { id: '3', name: 'Tetris', category: 'Puzzle', thumbnail: '', url: 'https://tetris.com/play-tetris', description: 'Classic block stacking puzzle game' },
  { id: '4', name: '2048', category: 'Puzzle', thumbnail: '', url: 'https://play2048.co/', description: 'Merge tiles to reach 2048' },
  { id: '5', name: 'Cookie Clicker', category: 'Idle', thumbnail: '', url: 'https://orteil.dashnet.org/cookieclicker/', description: 'Click cookies and build your empire' },
  { id: '6', name: 'Snake', category: 'Classic', thumbnail: '', url: 'https://playsnake.org/', description: 'Classic snake game - eat and grow' },
  { id: '7', name: 'Minecraft Classic', category: 'Sandbox', thumbnail: '', url: 'https://classic.minecraft.net/', description: 'Build and explore in classic Minecraft' },
  { id: '8', name: 'Agar.io', category: 'Multiplayer', thumbnail: '', url: 'https://agar.io/', description: 'Grow your cell and eat others' },
  { id: '9', name: 'Slither.io', category: 'Multiplayer', thumbnail: '', url: 'https://slither.io/', description: 'Become the biggest snake' },
  { id: '10', name: 'Pac-Man', category: 'Classic', thumbnail: '', url: 'https://pacman.com/', description: 'Eat dots and avoid ghosts' },
  { id: '11', name: 'Flappy Bird', category: 'Arcade', thumbnail: '', url: 'https://flappybird.io/', description: 'Fly through pipes' },
  { id: '12', name: 'Chess', category: 'Strategy', thumbnail: '', url: 'https://chess.com/', description: 'Classic chess game' },
  { id: '13', name: 'Solitaire', category: 'Card', thumbnail: '', url: 'https://solitr.com/', description: 'Classic card game' },
  { id: '14', name: 'Tic Tac Toe', category: 'Classic', thumbnail: '', url: 'https://playtictactoe.org/', description: 'X and O strategy game' },
  { id: '15', name: 'Basketball Stars', category: 'Sports', thumbnail: '', url: 'https://basketball-stars.io/', description: '1v1 basketball game' },
  { id: '16', name: 'Drift Hunters', category: 'Racing', thumbnail: '', url: 'https://drift-hunters.io/', description: 'Drift racing game' },
  { id: '17', name: 'Run 3', category: 'Endless Runner', thumbnail: '', url: 'https://run3.io/', description: 'Run through space tunnels' },
  { id: '18', name: 'Happy Wheels', category: 'Physics', thumbnail: '', url: 'https://totaljerkface.com/happy_wheels.tjf', description: 'Physics-based racing game' },
  { id: '19', name: 'Tank Trouble', category: 'Action', thumbnail: '', url: 'https://tanktrouble.com/', description: 'Tank battle game' },
  { id: '20', name: 'Super Mario Bros', category: 'Platformer', thumbnail: '', url: 'https://supermariobros.io/', description: 'Classic Mario platformer' },
  { id: '21', name: 'Geometry Dash', category: 'Rhythm', thumbnail: '', url: 'https://geometrydash.io/', description: 'Rhythm-based platformer' },
  { id: '22', name: 'Among Us', category: 'Multiplayer', thumbnail: '', url: 'https://amongusplay.online/', description: 'Find the impostor' },
  { id: '23', name: 'Paper.io', category: 'IO Game', thumbnail: '', url: 'https://paper-io.com/', description: 'Capture territory' },
  { id: '24', name: 'Krunker.io', category: 'FPS', thumbnail: '', url: 'https://krunker.io/', description: 'Browser-based FPS' },
  { id: '25', name: 'Shell Shockers', category: 'FPS', thumbnail: '', url: 'https://shellshock.io/', description: 'Egg-based multiplayer shooter' },
  { id: '26', name: 'Zombs Royale', category: 'Battle Royale', thumbnail: '', url: 'https://zombsroyale.io/', description: '2D battle royale game' },
  { id: '27', name: 'Surviv.io', category: 'Battle Royale', thumbnail: '', url: 'https://surviv.io/', description: 'Top-down battle royale' },
  { id: '28', name: 'Moomoo.io', category: 'IO Game', thumbnail: '', url: 'https://moomoo.io/', description: 'Build and survive' },
  { id: '29', name: 'Diep.io', category: 'IO Game', thumbnail: '', url: 'https://diep.io/', description: 'Tank battle arena' },
  { id: '30', name: 'Wings.io', category: 'IO Game', thumbnail: '', url: 'https://wings.io/', description: 'Airplane dogfight' },
  { id: '31', name: 'Limax.io', category: 'IO Game', thumbnail: '', url: 'https://limax.io/', description: 'Slime battle arena' },
  { id: '32', name: 'Splix.io', category: 'IO Game', thumbnail: '', url: 'https://splix.io/', description: 'Capture territory' },
  { id: '33', name: 'Narwhale.io', category: 'IO Game', thumbnail: '', url: 'https://narwhale.io/', description: 'Narwhal battle game' },
  { id: '34', name: 'Starve.io', category: 'Survival', thumbnail: '', url: 'https://starve.io/', description: 'Survive the wilderness' },
  { id: '35', name: 'Deeeep.io', category: 'IO Game', thumbnail: '', url: 'https://deeeep.io/', description: 'Underwater evolution game' },
  { id: '36', name: 'Brutal.io', category: 'IO Game', thumbnail: '', url: 'https://brutal.io/', description: 'Flail combat game' },
  { id: '37', name: 'Spinz.io', category: 'IO Game', thumbnail: '', url: 'https://spinz.io/', description: 'Fidget spinner battle' },
  { id: '38', name: 'Boas.io', category: 'IO Game', thumbnail: '', url: 'https://boas.io/', description: 'Snake territory capture' },
  { id: '39', name: 'Pikes.io', category: 'IO Game', thumbnail: '', url: 'https://pikes.io/', description: 'Spear battle arena' },
  { id: '40', name: 'Swordz.io', category: 'IO Game', thumbnail: '', url: 'https://swordz.io/', description: 'Sword fighting game' },
  { id: '41', name: 'Tribs.io', category: 'IO Game', thumbnail: '', url: 'https://tribs.io/', description: 'Tribal warfare' },
  { id: '42', name: 'Fightz.io', category: 'IO Game', thumbnail: '', url: 'https://fightz.io/', description: 'Animal battle arena' },
  { id: '43', name: 'Kugeln.io', category: 'Shooter', thumbnail: '', url: 'https://kugeln.io/', description: '2D multiplayer shooter' },
  { id: '44', name: 'Wilds.io', category: 'Action', thumbnail: '', url: 'https://wilds.io/', description: 'Medieval combat' },
  { id: '45', name: 'Gartic.io', category: 'IO Game', thumbnail: '', url: 'https://gartic.io/', description: 'Draw and guess' },
  { id: '46', name: 'Skribbl.io', category: 'IO Game', thumbnail: '', url: 'https://skribbl.io/', description: 'Pictionary online' },
  { id: '47', name: 'Bonk.io', category: 'Physics', thumbnail: '', url: 'https://bonk.io/', description: 'Physics-based combat' },
  { id: '48', name: 'Wormax.io', category: 'IO Game', thumbnail: '', url: 'https://wormax.io/', description: 'Worm battle game' },
  { id: '49', name: 'Little Big Snake', category: 'IO Game', thumbnail: '', url: 'https://littlebigsnake.com/', description: 'Snake adventure' },
  { id: '50', name: 'Worms Zone', category: 'IO Game', thumbnail: '', url: 'https://wormszone.io/', description: 'Worm eating game' },
  { id: '51', name: 'Snake.is', category: 'IO Game', thumbnail: '', url: 'https://snake.is/', description: '3D snake game' },
  { id: '52', name: 'Hexar.io', category: 'IO Game', thumbnail: '', url: 'https://hexar.io/', description: 'Hexagon territory game' },
  { id: '53', name: 'Superhex.io', category: 'IO Game', thumbnail: '', url: 'https://superhex.io/', description: 'Hexagon capture game' },
  { id: '54', name: 'Defly.io', category: 'IO Game', thumbnail: '', url: 'https://defly.io/', description: 'Helicopter territory' },
  { id: '55', name: 'Copter.io', category: 'IO Game', thumbnail: '', url: 'https://copter.io/', description: 'Helicopter battle' },
  { id: '56', name: 'Airma.sh', category: 'IO Game', thumbnail: '', url: 'https://airma.sh/', description: 'Aircraft combat' },
  { id: '57', name: 'Space1.io', category: 'IO Game', thumbnail: '', url: 'https://space1.io/', description: 'Space shooter' },
  { id: '58', name: 'Astroe.io', category: 'IO Game', thumbnail: '', url: 'https://astroe.io/', description: 'Space mining battle' },
  { id: '59', name: 'Oib.io', category: 'IO Game', thumbnail: '', url: 'https://oib.io/', description: 'Blob army battle' },
  { id: '60', name: 'Cellcraft.io', category: 'IO Game', thumbnail: '', url: 'https://cellcraft.io/', description: 'Cell evolution game' },
  { id: '61', name: 'Pokerogue', category: 'RPG', thumbnail: '', url: 'https://pokerogue.net/', description: 'Pokemon roguelike' },
  { id: '62', name: 'Infinite Craft', category: 'Sandbox', thumbnail: '', url: 'https://neal.fun/infinite-craft/', description: 'Combine elements endlessly' },
  { id: '63', name: 'Little Alchemy 2', category: 'Puzzle', thumbnail: '', url: 'https://littlealchemy2.com/', description: 'Combine to create' },
  { id: '64', name: 'Sandspiel', category: 'Sandbox', thumbnail: '', url: 'https://sandspiel.club/', description: 'Falling sand physics' },
  { id: '65', name: 'Powder Game', category: 'Sandbox', thumbnail: '', url: 'https://dan-ball.jp/en/javagame/dust/', description: 'Particle physics sim' },
  { id: '66', name: 'The Sandbox', category: 'Sandbox', thumbnail: '', url: 'https://thesandbox.io/', description: 'Create your world' },
  { id: '67', name: 'WorldBox', category: 'Sandbox', thumbnail: '', url: 'https://www.superworldbox.com/', description: 'God simulator' },
  { id: '68', name: 'Cell Lab', category: 'Simulation', thumbnail: '', url: 'https://cell-lab.net/', description: 'Cell evolution sim' },
  { id: '69', name: 'Evolution', category: 'Simulation', thumbnail: '', url: 'https://evolution.com/', description: 'Evolution simulator' },
  { id: '70', name: 'Spore', category: 'Simulation', thumbnail: '', url: 'https://spore.com/', description: 'Evolution game' },
  { id: '71', name: 'Osmos', category: 'Puzzle', thumbnail: '', url: 'https://osmos-game.com/', description: 'Absorb smaller orbs' },
  { id: '72', name: 'Flow Free', category: 'Puzzle', thumbnail: '', url: 'https://www.flowfree.com/', description: 'Connect matching colors' },
  { id: '73', name: 'Cut the Rope', category: 'Puzzle', thumbnail: '', url: 'https://www.cuttherope.net/', description: 'Feed Om Nom candy' },
  { id: '74', name: 'Fruit Ninja', category: 'Arcade', thumbnail: '', url: 'https://fruitninja.com/', description: 'Slice flying fruit' },
  { id: '75', name: 'Temple Run 2', category: 'Endless Runner', thumbnail: '', url: 'https://templerun2.com/', description: 'Run from demon monkeys' },
  { id: '76', name: 'Jetpack Joyride', category: 'Arcade', thumbnail: '', url: 'https://jetpackjoyride.com/', description: 'Fly with jetpack' },
  { id: '77', name: 'Crossy Road', category: 'Arcade', thumbnail: '', url: 'https://crossyroad.com/', description: 'Cross busy roads' },
  { id: '78', name: 'Doodle Jump', category: 'Arcade', thumbnail: '', url: 'https://doodlejump.org/', description: 'Jump endlessly upward' },
  { id: '79', name: 'Frogger', category: 'Classic', thumbnail: '', url: 'https://frogger.org/', description: 'Cross roads and rivers' },
  { id: '80', name: 'QWOP', category: 'Sports', thumbnail: '', url: 'https://qwop.org/', description: 'Control runner legs' },
  { id: '81', name: 'Getting Over It', category: 'Physics', thumbnail: '', url: 'https://gettingoverit.co/', description: 'Climb with hammer' },
  { id: '82', name: 'Pogo Stick', category: 'Arcade', thumbnail: '', url: 'https://pogostick.io/', description: 'Bounce to victory' },
  { id: '83', name: 'Helix Jump', category: 'Arcade', thumbnail: '', url: 'https://helixjump.io/', description: 'Bounce down tower' },
  { id: '84', name: 'Stack', category: 'Arcade', thumbnail: '', url: 'https://stack.io/', description: 'Stack blocks perfectly' },
  { id: '85', name: 'Twist', category: 'Arcade', thumbnail: '', url: 'https://twist.io/', description: 'Navigate the twist' },
  { id: '86', name: 'Rise Up', category: 'Arcade', thumbnail: '', url: 'https://riseup.io/', description: 'Protect the balloon' },
  { id: '87', name: 'Color Switch', category: 'Arcade', thumbnail: '', url: 'https://colorswitch.org/', description: 'Match colors to pass' },
  { id: '88', name: 'Tap Tap Dash', category: 'Arcade', thumbnail: '', url: 'https://taptapdash.com/', description: 'Tap to turn' },
  { id: '89', name: 'Alto Adventure', category: 'Endless Runner', thumbnail: '', url: 'https://altoadventure.com/', description: 'Snowboard journey' },
  { id: '90', name: 'Ski Safari', category: 'Endless Runner', thumbnail: '', url: 'https://skisafari.com/', description: 'Escape the avalanche' },
  { id: '91', name: 'Tiny Wings', category: 'Arcade', thumbnail: '', url: 'https://tinywings.com/', description: 'Slide and fly' },
  { id: '92', name: 'Badland', category: 'Adventure', thumbnail: '', url: 'https://badland.com/', description: 'Atmospheric adventure' },
  { id: '93', name: 'Limbo', category: 'Adventure', thumbnail: '', url: 'https://limbogame.com/', description: 'Dark puzzle platformer' },
  { id: '94', name: 'Inside', category: 'Adventure', thumbnail: '', url: 'https://playdead.com/inside/', description: 'Atmospheric platformer' },
  { id: '95', name: 'Fireboy & Watergirl', category: 'Puzzle', thumbnail: '', url: 'https://fireboyandwatergirl.co/', description: 'Cooperative puzzle game' },
  { id: '96', name: 'Red Ball', category: 'Platformer', thumbnail: '', url: 'https://redball4.com/', description: 'Roll and jump adventure' },
  { id: '97', name: 'Vex', category: 'Platformer', thumbnail: '', url: 'https://vex.io/', description: 'Challenging platformer' },
  { id: '98', name: 'Give Up Robot', category: 'Platformer', thumbnail: '', url: 'https://giveuprobot.com/', description: 'Grappling platformer' },
  { id: '99', name: 'The Impossible Quiz', category: 'Puzzle', thumbnail: '', url: 'https://theimpossiblequiz.com/', description: 'Tricky trivia game' },
  { id: '100', name: 'World Hardest Game', category: 'Arcade', thumbnail: '', url: 'https://worldshardestgame.io/', description: 'Extremely difficult game' },
  { id: '101', name: 'Cat Ninja', category: 'Platformer', thumbnail: '', url: 'https://catninja.org/', description: 'Ninja cat platformer' },
  { id: '102', name: 'Duck Life', category: 'Sports', thumbnail: '', url: 'https://ducklife.com/', description: 'Train your duck' },
  { id: '103', name: 'Learn to Fly', category: 'Arcade', thumbnail: '', url: 'https://learntofly.com/', description: 'Teach penguin to fly' },
  { id: '104', name: 'Shopping Cart Hero', category: 'Arcade', thumbnail: '', url: 'https://shoppingcarthero.com/', description: 'Launch shopping cart' },
  { id: '105', name: 'Burrito Bison', category: 'Arcade', thumbnail: '', url: 'https://burritobison.com/', description: 'Launch wrestling game' },
  { id: '106', name: 'Toss the Turtle', category: 'Arcade', thumbnail: '', url: 'https://tosstheturtle.com/', description: 'Launch turtle game' },
  { id: '107', name: 'Kitten Cannon', category: 'Arcade', thumbnail: '', url: 'https://kittencannon.com/', description: 'Launch kitten game' },
  { id: '108', name: 'Penguin Diner', category: 'Simulation', thumbnail: '', url: 'https://penguindiner.com/', description: 'Run penguin restaurant' },
  { id: '109', name: 'Papa Pizzeria', category: 'Simulation', thumbnail: '', url: 'https://papaspizzeria.io/', description: 'Make pizzas' },
  { id: '110', name: 'Papa Burgeria', category: 'Simulation', thumbnail: '', url: 'https://papasburgeria.io/', description: 'Make burgers' },
  { id: '111', name: 'Papa Freezeria', category: 'Simulation', thumbnail: '', url: 'https://papasfreezeria.io/', description: 'Make ice cream' },
  { id: '112', name: 'Papa Cupcakeria', category: 'Simulation', thumbnail: '', url: 'https://papascupcakeria.io/', description: 'Make cupcakes' },
  { id: '113', name: 'Papa Sushiria', category: 'Simulation', thumbnail: '', url: 'https://papassushiria.io/', description: 'Make sushi' },
  { id: '114', name: 'Papa Hot Doggeria', category: 'Simulation', thumbnail: '', url: 'https://papashotdoggeria.io/', description: 'Make hot dogs' },
  { id: '115', name: 'Papa Wingeria', category: 'Simulation', thumbnail: '', url: 'https://papaswingeria.io/', description: 'Make chicken wings' },
  { id: '116', name: 'Papa Cheeseria', category: 'Simulation', thumbnail: '', url: 'https://papascheeseria.io/', description: 'Make grilled cheese' },
  { id: '117', name: 'Papa Bakeria', category: 'Simulation', thumbnail: '', url: 'https://papasbakeria.io/', description: 'Bake pies' },
  { id: '118', name: 'Papa Donuteria', category: 'Simulation', thumbnail: '', url: 'https://papasdonuteria.io/', description: 'Make donuts' },
  { id: '119', name: 'Papa Pastaria', category: 'Simulation', thumbnail: '', url: 'https://papaspastaria.io/', description: 'Make pasta' },
  { id: '120', name: 'Papa Scooperia', category: 'Simulation', thumbnail: '', url: 'https://papasscooperia.io/', description: 'Make cookies and ice cream' }
];

// Categories
const categories = ['All', 'Arcade', 'Puzzle', 'Classic', 'Multiplayer', 'Action', 'Racing', 'Sports', 'Strategy', 'IO Game', 'FPS', 'Endless Runner', 'Idle', 'Sandbox', 'Physics', 'Platformer', 'Rhythm', 'Card', 'Battle Royale', 'Survival', 'Shooter', 'RPG', 'Simulation', 'Adventure'];

function App() {
  const [activeCloak, setActiveCloak] = useState<CloakType>('none');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [proxyUrl, setProxyUrl] = useState('');
  const [proxyFrameUrl, setProxyFrameUrl] = useState('');
  const [isProxyOpen, setIsProxyOpen] = useState(false);
  const [showCloakMenu, setShowCloakMenu] = useState(false);

  // Apply cloak effect
  useEffect(() => {
    const originalTitle = document.title;
    
    switch (activeCloak) {
      case 'blank':
        document.title = 'about:blank';
        break;
      case 'classroom':
        document.title = 'Google Classroom';
        break;
      case 'newtab':
        document.title = 'New Tab';
        break;
      default:
        document.title = originalTitle;
    }

    return () => {
      document.title = originalTitle;
    };
  }, [activeCloak]);

  // Filter games
  const filteredGames = games.filter(game => {
    const matchesSearch = game.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || game.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Handle game launch
  const launchGame = (game: Game) => {
    setSelectedGame(game);
  };

  // Handle proxy navigation
  const handleProxyNavigate = () => {
    if (!proxyUrl) {
      toast.error('Please enter a URL');
      return;
    }
    
    let url = proxyUrl;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    setProxyFrameUrl(url);
    setIsProxyOpen(true);
    toast.success('Loading...');
  };

  // Cloak overlay component
  const CloakOverlay = () => {
    if (activeCloak === 'none') return null;

    const cloakContent = {
      blank: (
        <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
          <div className="text-gray-400 text-sm">about:blank</div>
        </div>
      ),
      classroom: (
        <div className="fixed inset-0 bg-white z-50">
          <div className="bg-[#1967d2] h-16 flex items-center px-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-[#1967d2]" />
              </div>
              <span className="text-white font-medium text-lg">Classroom</span>
            </div>
          </div>
          <div className="p-8">
            <div className="text-2xl text-gray-700 mb-4">Classes</div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="h-24 bg-gradient-to-r from-blue-400 to-blue-600 rounded-t-lg mb-3"></div>
                  <div className="font-medium text-gray-800">Class {i}</div>
                  <div className="text-sm text-gray-500">Period {i}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ),
      newtab: (
        <div className="fixed inset-0 bg-[#202124] z-50 flex flex-col items-center justify-center">
          <div className="text-8xl font-light text-white mb-8 tracking-tight">Google</div>
          <div className="w-full max-w-2xl px-4">
            <div className="bg-[#303134] rounded-full px-6 py-4 flex items-center gap-4">
              <Search className="w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                className="bg-transparent text-white flex-1 outline-none text-lg"
                placeholder="Search Google or type a URL"
                readOnly
              />
            </div>
          </div>
          <div className="mt-8 flex gap-4">
            {['Gmail', 'Images', 'YouTube'].map((item) => (
              <div key={item} className="text-[#9aa0a6] text-sm hover:text-white cursor-pointer">
                {item}
              </div>
            ))}
          </div>
        </div>
      )
    };

    return (
      <div 
        className="fixed inset-0 z-50 cursor-pointer"
        onClick={() => setActiveCloak('none')}
      >
        {cloakContent[activeCloak]}
        <div className="absolute top-4 right-4 bg-black/70 text-white px-4 py-2 rounded-lg text-sm">
          Click anywhere to exit cloak mode
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Cloak Overlay */}
      <CloakOverlay />
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">FlashLightHub</h1>
                <p className="text-xs text-gray-400">Unblocked Games & Proxy</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Cloak Menu */}
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCloakMenu(!showCloakMenu)}
                  className="border-white/20 bg-white/5 text-white hover:bg-white/10"
                >
                  {activeCloak === 'none' ? <Eye className="w-4 h-4 mr-2" /> : <EyeOff className="w-4 h-4 mr-2" />}
                  Cloak
                </Button>
                
                {showCloakMenu && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-slate-800 border border-white/10 rounded-lg shadow-xl overflow-hidden">
                    <button
                      onClick={() => { setActiveCloak('none'); setShowCloakMenu(false); }}
                      className={`w-full px-4 py-3 text-left text-sm flex items-center gap-2 hover:bg-white/5 ${activeCloak === 'none' ? 'bg-white/10 text-yellow-400' : 'text-white'}`}
                    >
                      <Home className="w-4 h-4" />
                      Normal Mode
                    </button>
                    <button
                      onClick={() => { setActiveCloak('blank'); setShowCloakMenu(false); }}
                      className={`w-full px-4 py-3 text-left text-sm flex items-center gap-2 hover:bg-white/5 ${activeCloak === 'blank' ? 'bg-white/10 text-yellow-400' : 'text-white'}`}
                    >
                      <FileText className="w-4 h-4" />
                      about:blank
                    </button>
                    <button
                      onClick={() => { setActiveCloak('classroom'); setShowCloakMenu(false); }}
                      className={`w-full px-4 py-3 text-left text-sm flex items-center gap-2 hover:bg-white/5 ${activeCloak === 'classroom' ? 'bg-white/10 text-yellow-400' : 'text-white'}`}
                    >
                      <BookOpen className="w-4 h-4" />
                      Google Classroom
                    </button>
                    <button
                      onClick={() => { setActiveCloak('newtab'); setShowCloakMenu(false); }}
                      className={`w-full px-4 py-3 text-left text-sm flex items-center gap-2 hover:bg-white/5 ${activeCloak === 'newtab' ? 'bg-white/10 text-yellow-400' : 'text-white'}`}
                    >
                      <Monitor className="w-4 h-4" />
                      New Tab
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <Tabs defaultValue="games" className="w-full">
          <TabsList className="w-full max-w-md mx-auto mb-8 bg-white/5 border border-white/10 p-1">
            <TabsTrigger 
              value="games" 
              className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-400 data-[state=active]:to-orange-500 data-[state=active]:text-white text-gray-400"
            >
              <Gamepad2 className="w-4 h-4 mr-2" />
              Games
            </TabsTrigger>
            <TabsTrigger 
              value="proxy"
              className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-400 data-[state=active]:to-orange-500 data-[state=active]:text-white text-gray-400"
            >
              <Globe className="w-4 h-4 mr-2" />
              Unblocker
            </TabsTrigger>
          </TabsList>

          {/* Games Tab */}
          <TabsContent value="games" className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search games..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400/50"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat} className="bg-slate-800">{cat}</option>
                ))}
              </select>
            </div>

            {/* Games Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {filteredGames.map((game) => (
                <Card 
                  key={game.id}
                  className="bg-white/5 border-white/10 hover:border-yellow-400/50 transition-all cursor-pointer group overflow-hidden"
                  onClick={() => launchGame(game)}
                >
                  <div className="aspect-square bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center relative overflow-hidden">
                    <Gamepad2 className="w-12 h-12 text-gray-600 group-hover:text-yellow-400 transition-colors" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4">
                      <span className="text-white text-sm font-medium flex items-center gap-1">
                        <Play className="w-4 h-4" /> Play
                      </span>
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <h3 className="text-white font-medium text-sm truncate">{game.name}</h3>
                    <p className="text-gray-500 text-xs">{game.category}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredGames.length === 0 && (
              <div className="text-center py-16">
                <Gamepad2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">No games found</p>
              </div>
            )}
          </TabsContent>

          {/* Proxy Tab */}
          <TabsContent value="proxy" className="space-y-6">
            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5 text-yellow-400" />
                  FlashLight Unblocker
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400 text-sm">
                  Enter any URL to access blocked websites including YouTube, social media, and more.
                </p>
                <div className="flex gap-3">
                  <Input
                    placeholder="Enter URL (e.g., youtube.com)"
                    value={proxyUrl}
                    onChange={(e) => setProxyUrl(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleProxyNavigate()}
                    className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  />
                  <Button 
                    onClick={handleProxyNavigate}
                    className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white hover:opacity-90"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Go
                  </Button>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <p className="text-sm text-gray-500 mb-3">Quick Links:</p>
                  <div className="flex flex-wrap gap-2">
                    {['youtube.com', 'tiktok.com', 'discord.com', 'twitch.tv', 'reddit.com', 'netflix.com'].map((site) => (
                      <button
                        key={site}
                        onClick={() => {
                          setProxyUrl(site);
                          setTimeout(handleProxyNavigate, 100);
                        }}
                        className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm text-gray-300 transition-colors"
                      >
                        {site}
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Proxy Frame */}
            {isProxyOpen && (
              <Card className="bg-white/5 border-white/10">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Globe className="w-4 h-4 text-yellow-400" />
                    {proxyFrameUrl}
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsProxyOpen(false)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-black rounded-lg overflow-hidden">
                    <iframe
                      src={proxyFrameUrl}
                      className="w-full h-full"
                      sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                      allow="fullscreen; autoplay; clipboard-write"
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Game Dialog */}
      <Dialog open={!!selectedGame} onOpenChange={() => setSelectedGame(null)}>
        <DialogContent className="max-w-6xl w-[95vw] h-[90vh] bg-slate-900 border-white/10 p-0 overflow-hidden">
          {selectedGame && (
            <>
              <DialogHeader className="px-6 py-4 border-b border-white/10">
                <div className="flex items-center justify-between">
                  <DialogTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    {selectedGame.name}
                  </DialogTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(selectedGame?.url, '_blank')}
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open in New Tab
                    </Button>
                  </div>
                </div>
              </DialogHeader>
              <div className="flex-1 h-[calc(90vh-80px)] bg-black">
                <iframe
                  src={selectedGame.url}
                  className="w-full h-full"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                  allow="fullscreen; autoplay; clipboard-write; microphone; camera"
                />
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-yellow-400" />
            <span className="text-white font-bold">FlashLightHub</span>
          </div>
          <p className="text-gray-500 text-sm">
            Play unblocked games and access any website with our built-in proxy.
          </p>
          <p className="text-gray-600 text-xs mt-2">
            Use the cloak feature to hide this page when needed.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
